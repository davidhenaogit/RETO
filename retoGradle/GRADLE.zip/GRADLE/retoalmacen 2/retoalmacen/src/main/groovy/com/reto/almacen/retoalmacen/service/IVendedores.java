package com.reto.almacen.retoalmacen.service;

import org.springframework.http.ResponseEntity;

public interface IVendedores {


    ResponseEntity listarVendedores();


}
