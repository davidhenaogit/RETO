package com.reto.almacen.retoalmacen

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class RetoalmacenApplication {

	static void main(String[] args) {
		SpringApplication.run(RetoalmacenApplication, args)
	}

}
