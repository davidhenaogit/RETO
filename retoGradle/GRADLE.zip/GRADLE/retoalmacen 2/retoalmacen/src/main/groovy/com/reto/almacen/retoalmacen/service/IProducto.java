package com.reto.almacen.retoalmacen.service;

import org.springframework.http.ResponseEntity;

public interface IProducto {


    ResponseEntity listarProducto();


}


