package com.reto.almacen.retoalmacen

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RetoalmacenApplicationTests {

	@Test
	void contextLoads() {
	}

}
