package com.reto.gradle.war;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarApplicationTests {

	@Test
	void contextLoads() {
	}

}
