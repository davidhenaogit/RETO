package com.reto.gradle.war.service;

import org.springframework.http.ResponseEntity;

public interface IProductoService {


    ResponseEntity listarProducto();

}


