package com.reto.gradle.war.controller;

import com.reto.gradle.war.service.IVentasService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ventas")
public class VentasController {

    private final IVentasService iVentasService;

    public VentasController(IVentasService iVentasService) {
        this.iVentasService = iVentasService;
    }

    @GetMapping
    public ResponseEntity getAllVentas() {
        return iVentasService.listarVentas();
    }

    @GetMapping("/fecha")
    public ResponseEntity totalCantidadVendida(@RequestParam String fechaVenta) {
        return iVentasService.totalVentasPorFecha(fechaVenta);
    }

}
