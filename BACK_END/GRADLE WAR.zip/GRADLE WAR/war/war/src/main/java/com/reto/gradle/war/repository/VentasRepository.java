package com.reto.gradle.war.repository;

import com.reto.gradle.war.entity.VentasEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface VentasRepository extends JpaRepository<VentasEntity, Long> {

    VentasEntity findByCantidadVendida(String cantidadVendida);

    List<VentasEntity> findByFechaVenta(Date date);

}
