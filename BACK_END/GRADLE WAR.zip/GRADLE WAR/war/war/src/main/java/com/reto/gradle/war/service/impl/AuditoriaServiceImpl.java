package com.reto.gradle.war.service.impl;

import com.reto.gradle.war.repository.AuditoriaRepository;
import com.reto.gradle.war.service.IAuditoriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AuditoriaServiceImpl implements IAuditoriaService {

    private final AuditoriaRepository auditoriaRepository;

    public AuditoriaServiceImpl(AuditoriaRepository auditoriaRepository) {
        this.auditoriaRepository = auditoriaRepository;
    }

    @Override
    public ResponseEntity listarDatos() {
        return ResponseEntity.ok(auditoriaRepository.findAll());
    }


}
