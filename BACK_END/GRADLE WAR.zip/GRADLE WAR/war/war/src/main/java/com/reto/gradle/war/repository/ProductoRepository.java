package com.reto.gradle.war.repository;


import com.reto.gradle.war.entity.ProductoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<ProductoEntity, Long> {

    ProductoEntity findByIdProducto(String idProducto);

}
