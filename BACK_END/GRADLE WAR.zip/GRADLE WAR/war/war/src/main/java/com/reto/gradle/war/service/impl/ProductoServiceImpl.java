package com.reto.gradle.war.service.impl;

import com.reto.gradle.war.repository.ProductoRepository;
import com.reto.gradle.war.service.IProductoService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ProductoServiceImpl implements IProductoService {

    private final ProductoRepository productoRepository;

    public ProductoServiceImpl(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    @Override
    public ResponseEntity listarProducto() {
        return ResponseEntity.ok(productoRepository.findAll());
    }


}
