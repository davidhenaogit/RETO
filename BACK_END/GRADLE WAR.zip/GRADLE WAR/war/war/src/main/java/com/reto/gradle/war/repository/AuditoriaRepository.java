package com.reto.gradle.war.repository;

import com.reto.gradle.war.entity.AuditoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditoriaRepository extends JpaRepository<AuditoriaEntity, Long> {

    AuditoriaEntity findByIdAuditoria(String idAuditoria);

}
