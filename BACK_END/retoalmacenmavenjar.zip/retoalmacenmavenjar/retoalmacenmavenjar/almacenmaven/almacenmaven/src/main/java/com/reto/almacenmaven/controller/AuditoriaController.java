package com.reto.almacenmaven.controller;

import com.reto.almacenmaven.service.IAuditoriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auditoria")

public class AuditoriaController {

    private final IAuditoriaService iAuditoriaService;

    public AuditoriaController(IAuditoriaService iAuditoriaService) {
        this.iAuditoriaService = iAuditoriaService;
    }

    @GetMapping
    public ResponseEntity getAllDatos() {
        return iAuditoriaService.listarDatos();
    }

}
