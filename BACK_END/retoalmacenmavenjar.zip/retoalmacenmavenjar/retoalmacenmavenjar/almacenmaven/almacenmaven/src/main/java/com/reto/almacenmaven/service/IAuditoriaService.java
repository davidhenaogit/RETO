package com.reto.almacenmaven.service;

import org.springframework.http.ResponseEntity;

public interface IAuditoriaService {

    ResponseEntity listarDatos();

}
