package com.reto.almacenmaven.controller;

import com.reto.almacenmaven.service.IVendedoresService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/vendedores")
public class VendedoresController {

    private final IVendedoresService iVendedoresService;

    public VendedoresController(IVendedoresService iVendedoresService) {
        this.iVendedoresService = iVendedoresService;
    }

    @GetMapping
    public ResponseEntity getAllVendedores() {
        return iVendedoresService.listarVendedores();
    }
}
