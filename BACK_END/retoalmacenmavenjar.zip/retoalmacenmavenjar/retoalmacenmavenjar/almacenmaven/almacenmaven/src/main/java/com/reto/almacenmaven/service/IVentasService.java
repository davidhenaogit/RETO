package com.reto.almacenmaven.service;

import org.springframework.http.ResponseEntity;

public interface IVentasService {

    ResponseEntity listarVentas();

    ResponseEntity totalVentasPorFecha(String fechaVenta);

}
