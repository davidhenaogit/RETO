package com.reto.almacenmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenmavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenmavenApplication.class, args);
	}

}
