package com.reto.almacenmaven.service.impl;

import com.reto.almacenmaven.entity.VentasEntity;
import com.reto.almacenmaven.repository.VentasRepository;
import com.reto.almacenmaven.service.IVentasService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class VentasServiceImpl implements IVentasService {

    private final VentasRepository ventasRepository;

    public VentasServiceImpl(VentasRepository ventasRepository) {
        this.ventasRepository = ventasRepository;

    }

    @Override
    public ResponseEntity listarVentas() {

        return ResponseEntity.ok(ventasRepository.findAll());
    }

    @Override
    public ResponseEntity totalVentasPorFecha(String fechaVenta) {

        Date fechaConsulta = new Date();
        List<VentasEntity> ventasEntityList = ventasRepository.findByFechaVenta(fechaConsulta);

        return ResponseEntity.ok(ventasRepository);
    }


}
