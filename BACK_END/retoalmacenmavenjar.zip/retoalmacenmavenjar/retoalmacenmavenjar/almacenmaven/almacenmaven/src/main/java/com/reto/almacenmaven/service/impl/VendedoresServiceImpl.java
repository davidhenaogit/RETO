package com.reto.almacenmaven.service.impl;

import com.reto.almacenmaven.repository.VendedoresRepository;
import com.reto.almacenmaven.service.IVendedoresService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class VendedoresServiceImpl implements IVendedoresService {
    private final VendedoresRepository vendedoresRepository;

    public VendedoresServiceImpl(VendedoresRepository vendedoresRepository) {
        this.vendedoresRepository = vendedoresRepository;

    }

    @Override
    public ResponseEntity listarVendedores() {

        return ResponseEntity.ok(vendedoresRepository.findAll());
    }
}
