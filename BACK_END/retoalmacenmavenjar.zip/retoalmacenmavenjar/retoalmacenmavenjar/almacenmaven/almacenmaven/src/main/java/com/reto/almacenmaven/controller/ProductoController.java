package com.reto.almacenmaven.controller;

import com.reto.almacenmaven.service.IProductoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/producto")

public class ProductoController {

    private final IProductoService iProductoService;

    public ProductoController(IProductoService iProductoService) {
        this.iProductoService = iProductoService;
    }

    @GetMapping
    public ResponseEntity getAllProducto() {
        return iProductoService.listarProducto();
    }

}