package com.reto.almacenmaven.repository;

import com.reto.almacenmaven.entity.AuditoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditoriaRepository extends JpaRepository<AuditoriaEntity, Long> {

    AuditoriaEntity findByIdAuditoria(String idAuditoria);

}
