package com.reto.almacenmaven.repository;

import com.reto.almacenmaven.entity.VendedoresEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VendedoresRepository extends JpaRepository<VendedoresEntity, Long> {


    VendedoresEntity findByIdVendedor(String idVendedor);

}

