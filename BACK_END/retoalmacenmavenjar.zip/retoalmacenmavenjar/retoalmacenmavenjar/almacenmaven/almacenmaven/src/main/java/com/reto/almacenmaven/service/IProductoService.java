package com.reto.almacenmaven.service;

import org.springframework.http.ResponseEntity;

public interface IProductoService {


    ResponseEntity listarProducto();

}


