package com.reto.almacenmaven.controller;

import com.reto.almacenmaven.entity.VentasEntity;
import com.reto.almacenmaven.service.IVentasService;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;

@RestController
@RequestMapping("/ventas")
public class VentasController {

    private final IVentasService iVentasService;

    public VentasController(IVentasService iVentasService) {
        this.iVentasService = iVentasService;
    }

    @GetMapping
    public ResponseEntity getAllVentas() {
        return iVentasService.listarVentas();
    }

    @GetMapping("/fecha")
    public ResponseEntity totalCantidadVendida(@RequestParam String fechaVenta) {
        return iVentasService.totalVentasPorFecha(fechaVenta);
    }

}
