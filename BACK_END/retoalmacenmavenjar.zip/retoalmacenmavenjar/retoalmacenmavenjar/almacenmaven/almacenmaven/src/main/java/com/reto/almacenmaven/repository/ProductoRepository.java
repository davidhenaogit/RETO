package com.reto.almacenmaven.repository;


import com.reto.almacenmaven.entity.ProductoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<ProductoEntity, Long> {

    ProductoEntity findByIdProducto(String idProducto);

}
